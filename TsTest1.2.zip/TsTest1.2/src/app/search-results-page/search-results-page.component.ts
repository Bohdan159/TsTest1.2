import { Component, OnInit } from '@angular/core';
import { NestoriaService } from '../services/nestoria.service';
import { FavouritesService } from '../services/favourites.service';
import { Router, ActivatedRoute } from '@angular/router';
import {HeadService} from '../services/head.service';

@Component({
  selector: 'app-search-results-page',
  templateUrl: './search-results-page.component.html',
  styleUrls: ['./search-results-page.component.less'],
})
export class SearchResultsPageComponent implements OnInit {
  data;
  city;
  currentPage = 1;
  errorText;
  isFavourite = 0;
  error = 0;

  constructor(private nestoria: NestoriaService,
              private router: Router,
              private activatedRoute: ActivatedRoute,
              private favourites: FavouritesService,
              private head: HeadService) {
  }


  UpdateCounter(isFirst) {
    this.nestoria.changeCount(isFirst);
  }

  UpdateCurrentPage() {
    this.currentPage += 1;
  }

  getFavourites() {
    this.data = JSON.parse(localStorage.getItem('favourites'));
  }

  showLocation() {
    this.nestoria.getDataByCoordinats(this.currentPage, this.activatedRoute.snapshot.queryParams['latitude'], this.activatedRoute.snapshot.queryParams['longitude'] ).subscribe(data => {
      if(this.nestoria.checkLocationValidity(data) == 1) {
        this.data = data.response.listings;
        this.UpdateCounter(0);
        this.nestoria.changeTotalCount(data.response.total_results);
        this.UpdateCurrentPage();
      } else {
        this.error = 1;
        this.errorText = 'Wrong location';
      }
    });
  }


  showCity() {
    this.nestoria.getData(this.activatedRoute.snapshot.queryParams['city'], this.currentPage).subscribe(data => {
      if (this.nestoria.checkCityValidity(data) == 1 ) {
        this.data = data.response.listings;
        this.UpdateCounter(0);
        this.nestoria.changeTotalCount(data.response.total_results);
      } else {
        this.error = 1;
        this.errorText = 'Input error';
      }
    });
    this.UpdateCurrentPage();
  }

  showFavourites() {
    this.isFavourite = 1;
    this.head.changeHead('favourites');
    this.getFavourites();
  }

  ngOnInit() {
    this.head.changeHead('searchResultsPage');
    this.UpdateCounter(1);
    if (this.activatedRoute.snapshot.queryParams['latitude'] && this.activatedRoute.snapshot.queryParams['longitude']) {
      this.showLocation();
    } else if (this.router.url != '/favourites') {
      this.showCity();
    } else {
      this.showFavourites();
    }
  }

  openNote(note) {
    this.nestoria.changeNote(note);
    this.favourites.changeIsFavourite(this.isFavourite);
    this.router.navigate(['/note']);
  }

  addNotes() {
    if (this.activatedRoute.snapshot.queryParams['latitude'] && this.activatedRoute.snapshot.queryParams['longitude']) {
      this.nestoria.getDataByCoordinats(this.currentPage, this.activatedRoute.snapshot.queryParams['latitude'], this.activatedRoute.snapshot.queryParams['longitude']).subscribe(data => {
        this.data = this.data.concat(data.response.listings);
        this.UpdateCounter(0);
      });
      this.UpdateCurrentPage();
    } else {
      this.nestoria.getData(this.activatedRoute.snapshot.queryParams['city'], this.currentPage).subscribe(data => {
        this.data = this.data.concat(data.response.listings);
        this.UpdateCounter(0);
      });
      this.UpdateCurrentPage();
    }
  }
}






