import { Component, OnInit, OnDestroy } from '@angular/core';
import { NestoriaService } from '../services/nestoria.service';
import { Router } from '@angular/router';
import { RecentSearchesService } from '../services/recent-searches.service';
import { HeadService } from '../services/head.service';
import { FormBuilder, FormGroup } from '@angular/forms';


@Component({
  selector: 'app-search-page',
  templateUrl: './search-page.component.html',
  styleUrls: ['./search-page.component.less'],
})
export class SearchPageComponent implements OnInit {

  error = 0;
  errorText;
  myForm: FormGroup;

  constructor(private nestoria: NestoriaService,
              private router: Router,
              private recentSearchesService: RecentSearchesService,
              private headService: HeadService,
              private fb: FormBuilder) {

    this.myForm = fb.group({
      'place' : ['']
    });

  }
  //
  // onSubmit(place) {
  //   this.getDataByCity(place);
  // }

  getDataByCity(place: string) {
    this.nestoria.getData(place, 1).subscribe(data => {
      if (this.nestoria.checkCityValidity(data) == 1 ) {
        this.recentSearchesService.addRecentSearch(place);
        this.router.navigate(['/searchresults'] , {queryParams: {city: place} } );
      } else {
        this.error = 1;
        this.errorText = 'Input error';
      }
    });
  }

  getDataByLocation() {
    navigator.geolocation.getCurrentPosition(location => {
      this.nestoria.getDataByCoordinats(1, location.coords.latitude, location.coords.longitude).subscribe(data => {
        if(this.nestoria.checkLocationValidity(data) == 1) {
          this.router.navigate(['/searchresults'], { queryParams: { latitude: location.coords.latitude  , longitude: location.coords.longitude } });
        } else {
          this.error = 1;
          this.errorText = 'Wrong location';
        }
      });
    });
  }

  ngOnInit() {
    this.headService.changeHead('searchPageHead');
  }
}
