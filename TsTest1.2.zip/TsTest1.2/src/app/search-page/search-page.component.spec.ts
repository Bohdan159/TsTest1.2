import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SearchPageComponent } from './search-page.component';
import { RouterTestingModule } from '@angular/router/testing';
import { NestoriaService } from '../services/nestoria.service';
import { RecentSearchesComponent} from "../recent-searches/recent-searches.component";
import { RecentSearchComponent} from "../recent-search/recent-search.component";
import { RecentSearchesService} from "../services/recent-searches.service";
import { HeadService } from '../services/head.service';
import { HttpModule } from "@angular/http";
import { FormsModule, ReactiveFormsModule} from '@angular/forms';


describe('SearchPage', () => {
  let component: SearchPageComponent;
  let fixture: ComponentFixture<SearchPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchPageComponent, RecentSearchesComponent, RecentSearchComponent ],
      imports: [ RouterTestingModule, HttpModule, FormsModule,
        ReactiveFormsModule],
      providers: [ NestoriaService, RecentSearchesService, HeadService ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
