import { Routes, RouterModule }  from '@angular/router';
import { SearchPageComponent } from './search-page/search-page.component';
import { SearchResultsPageComponent } from './search-results-page/search-results-page.component';
import { NotePageComponent } from './note-page/note-page.component';

const routes: Routes = [
    {   path: '',
        component: SearchPageComponent
    },
    {
        path: 'searchresults',
        component: SearchResultsPageComponent
    },
    {
        path: 'note',
        component: NotePageComponent
    },
    {
        path: 'favourites',
        component: SearchResultsPageComponent
    }
];

export const appRouterModule = RouterModule.forRoot(routes);

