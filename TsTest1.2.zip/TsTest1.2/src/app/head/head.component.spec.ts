import {async, ComponentFixture,  TestBed} from '@angular/core/testing';


import { Http, HttpModule } from "@angular/http";
import { HeadComponent } from './head.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HeadService } from '../services/head.service';
import { NestoriaService } from '../services/nestoria.service';
import {ConnectionBackend} from "@angular/http";

describe('HeadComponent', () => {
  let component: HeadComponent;
  let fixture: ComponentFixture<HeadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HeadComponent ],
      imports: [ RouterTestingModule, HttpModule],
      providers: [NestoriaService, HeadService, HttpModule, Http, ConnectionBackend ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HeadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
