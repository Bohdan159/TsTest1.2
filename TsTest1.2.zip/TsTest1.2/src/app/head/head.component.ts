import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HeadService } from '../services/head.service';
import { NestoriaService } from '../services/nestoria.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-head',
  templateUrl: './head.component.html',
  styleUrls: ['./head.component.less'],
})
export class HeadComponent implements OnInit {

  headView: String;
  count;
  totalCount: Number;

  constructor(private router: Router,
              private head: HeadService,
              private nestoria: NestoriaService,
              private location: Location) { }

  ngOnInit() {
    this.head.currentHead.subscribe(head => this.headView = head);
    this.nestoria.currentCount.subscribe(count => this.count = count);
    this.nestoria.currentTotalCount.subscribe(totalCount => this.totalCount = totalCount);
  }

  openFavourites(): void {
    this.router.navigate(['/favourites']);
  }

  returnToSearchPage(): void {
    this.router.navigate(['/']);
  }

  returnToSearchResultsPage(): void {
    this.location.back();
  }
}
