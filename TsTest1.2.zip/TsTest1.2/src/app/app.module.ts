import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { JsonpModule, Jsonp, Response } from "@angular/http";

import { AppComponent } from './app.component';
import { SearchPageComponent } from './search-page/search-page.component';
import { RecentSearchesComponent } from './recent-searches/recent-searches.component';
import { RecentSearchComponent } from './recent-search/recent-search.component';
import { SearchResultsPageComponent } from './search-results-page/search-results-page.component';
import { appRouterModule } from './app.routes';
import { NestoriaService } from './services/nestoria.service';
import { SearchResultComponent } from './search-result/search-result.component';
import { NotePageComponent } from './note-page/note-page.component';
import { RecentSearchesService } from './services/recent-searches.service'
import {FavouritesService} from "./services/favourites.service";
import { HeadComponent } from './head/head.component';
import { HeadService } from "./services/head.service";

@NgModule({
  declarations: [
    AppComponent,
    SearchPageComponent,
    RecentSearchesComponent,
    RecentSearchComponent,
    SearchResultsPageComponent,
    SearchResultComponent,
    NotePageComponent,
    HeadComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    appRouterModule,
    FormsModule,
    ReactiveFormsModule,
    JsonpModule
  ],
  providers: [ NestoriaService, RecentSearchesService, FavouritesService, HeadService ],
  bootstrap: [AppComponent]
})
export class AppModule { }
