import {async, ComponentFixture,  TestBed} from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { NestoriaService } from '../services/nestoria.service';
import { RecentSearchComponent } from './recent-search.component';
import { HttpModule } from "@angular/http";


describe('RecentSearch', () => {
  let component: RecentSearchComponent;
  let fixture: ComponentFixture<RecentSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecentSearchComponent ],
      imports: [ RouterTestingModule, HttpModule],
      providers: [ NestoriaService]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecentSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
