import { Component, OnInit, Input } from '@angular/core';
import { Router , ActivatedRoute } from '@angular/router';
import { NestoriaService } from '../services/nestoria.service';

@Component({
  selector: 'app-recent-search',
  templateUrl: './recent-search.component.html',
  styleUrls: ['./recent-search.component.less']
})
export class RecentSearchComponent implements OnInit {

  @Input() title;

  constructor(private router: Router, private nestoria: NestoriaService ) { }

  ngOnInit() {
  }

  search(title) {
    this.nestoria.getData(title, 1).subscribe(data => {
      this.router.navigate(['/searchresults'], { queryParams: { city: title } });
    });
  }


}
