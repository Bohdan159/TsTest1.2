import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { NestoriaService } from '../services/nestoria.service';
import { RecentSearchComponent } from '../recent-search/recent-search.component';
import { RecentSearchesComponent } from './recent-searches.component';


describe('RecentSearches', () => {
  let component: RecentSearchesComponent;
  let fixture: ComponentFixture<RecentSearchesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecentSearchesComponent, RecentSearchComponent ],
      imports: [ RouterTestingModule],
      providers: [ NestoriaService]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecentSearchesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
