import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-recent-searches',
  templateUrl: './recent-searches.component.html',
  styleUrls: ['./recent-searches.component.less']
})
export class RecentSearchesComponent implements OnInit {

  recentSearches;

  constructor() { }

  ngOnInit() {
    this.recentSearches = JSON.parse(localStorage.getItem('recentSearches'));
  }

}
