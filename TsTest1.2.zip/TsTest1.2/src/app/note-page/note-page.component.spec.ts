import {async, ComponentFixture,  TestBed} from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HeadService } from '../services/head.service';
import { NestoriaService } from '../services/nestoria.service';
import { NotePageComponent } from './note-page.component';
import { FavouritesService} from '../services/favourites.service';
import { HttpModule} from "@angular/http";

describe('NotePage', () => {
  let component: NotePageComponent;
  let fixture: ComponentFixture<NotePageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NotePageComponent ],
      imports: [ RouterTestingModule, HttpModule],
      providers: [NestoriaService, HeadService, FavouritesService,  ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NotePageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
