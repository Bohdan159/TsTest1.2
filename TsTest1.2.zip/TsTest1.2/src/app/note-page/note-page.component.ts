import { Component, OnInit } from '@angular/core';
import { NestoriaService } from '../services/nestoria.service';
import { FavouritesService } from '../services/favourites.service';
import { Router } from '@angular/router';
import { HeadService } from '../services/head.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-note-page',
  templateUrl: './note-page.component.html',
  styleUrls: ['./note-page.component.less']
})
export class NotePageComponent implements OnInit {
  note;
  isFavourite;

  constructor(private nestoria: NestoriaService,
              private favourites: FavouritesService,
              private router: Router,
              private head: HeadService,
              private location: Location) {
  }

  ngOnInit() {
    this.nestoria.currentNote.subscribe(note => this.note = note);
    this.favourites.currentIsFavourite.subscribe(is => this.isFavourite = is);
    this.head.changeHead('notePage');
  }

  addToFavourites() {
    this.favourites.addToFavourites(this.note);
    this.location.back();
  }

  deleteFromFavourites() {
    this.favourites.deleteFromFavourites(this.note);
    this.router.navigate(['/favourites']);
  }

}
