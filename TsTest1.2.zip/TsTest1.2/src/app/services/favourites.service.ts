import { Injectable } from '@angular/core';
import "rxjs/add/operator/map";
import {BehaviorSubject} from 'rxjs/BehaviorSubject';

@Injectable()
export class FavouritesService {

  favourites;
  private isFavourite = new BehaviorSubject<Boolean>(false);
  currentIsFavourite = this.isFavourite.asObservable();

  changeIsFavourite(is) {
    this.isFavourite.next(is);
  }

  addToFavourites(note) {
    for (let index in this.favourites) {
      if (this.favourites[index].title === note.title) {
        return;
      }
    }
    this.favourites.push(note);
    localStorage.setItem('favourites', JSON.stringify(this.favourites));
  }

  deleteFromFavourites(note) {
    for (const index in this.favourites) {
      if (this.favourites[index].title === note.title) {
        this.favourites.splice(index, 1);
        localStorage.setItem('favourites', JSON.stringify(this.favourites));
        break;
      }
    }
  }

  getFavourites() {
    const array = localStorage.getItem('favourites');
    if (array == null) {
      this.favourites = [];
    } else {
      this.favourites = JSON.parse(array);
    }
  }

  constructor() {
    this.getFavourites();
  }

}
