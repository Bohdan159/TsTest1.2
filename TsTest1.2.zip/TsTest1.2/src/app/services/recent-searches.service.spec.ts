import { TestBed, inject } from '@angular/core/testing';

import { RecentSearchesService } from './recent-searches.service';

