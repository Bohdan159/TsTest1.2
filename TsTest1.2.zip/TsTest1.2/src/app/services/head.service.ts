import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class HeadService {

  private head = new BehaviorSubject<string>('');
  currentHead = this.head.asObservable();

  changeHead(head){
    this.head.next(head);
  }

  constructor() { }

}
