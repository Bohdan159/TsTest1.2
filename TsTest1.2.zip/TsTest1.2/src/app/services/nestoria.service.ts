import { Injectable } from '@angular/core';
import { Http, Jsonp } from '@angular/http';
import 'rxjs/add/operator/map';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';

@Injectable()
export class NestoriaService {
  private noteSource = new BehaviorSubject<Object>(null);
  currentNote = this.noteSource.asObservable();
  private countSource = new BehaviorSubject<number>(0);
  currentCount = this.countSource.asObservable();
  private totalCountSource = new BehaviorSubject<Number>(0);
  currentTotalCount = this.totalCountSource.asObservable();

  changeNote(note) {
    this.noteSource.next(note);
  }

  changeCount(isFirst) {
    if (isFirst === 1) {
      this.countSource.next(0);
    } else {
      this.countSource.next(this.countSource.value + 20);
    }
  }

  changeTotalCount(count) {
    this.totalCountSource.next(count);
  }

  constructor(private http: Http, private jsonp: Jsonp) {

  }

  getData(city, currentPage) {
    return this.jsonp.request("http://api.nestoria.co.uk/api?action=search_listings&encoding=json&pretty=1&listing_type=buy&place_name=" + city + "&page=" + currentPage + "&callback=JSONP_CALLBACK").map(data => data.json());
  }

  getDataByCoordinats(currentPage, lat, long) {
    return this.http.get("http://api.nestoria.co.uk/api?country=uk&pretty=1&action=search_listings&encoding=json&listing_type=buy&page=" + currentPage + "&centre_point=" + lat + "," + long ).map(data => data.json());
  }

  checkCityValidity(data): number {
    let answer;
    if (data.response.application_response_code == 100 || data.response.application_response_code == 101 || data.response.application_response_code == 110 ) {
      answer = 1;
    } else {
      answer = 0;
    }
    return answer;
  }

  checkLocationValidity(data) {
    let answer;
    if (data.response.listings == 0 ) {
      answer = 0;
    } else {
      answer = 1;
    }
    return answer;
  }

}
