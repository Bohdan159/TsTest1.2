import { TestBed, ComponentFixture, async,  inject } from '@angular/core/testing';
import { MockBackend } from '@angular/http/testing';

import { NestoriaService } from './nestoria.service';

import { HttpModule, XHRBackend, Response, ResponseOptions } from '@angular/http';



