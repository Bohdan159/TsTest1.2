import { TestBed, inject } from '@angular/core/testing';

import { HeadService } from './head.service';
