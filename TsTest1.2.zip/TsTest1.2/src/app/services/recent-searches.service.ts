import { Injectable } from '@angular/core';

@Injectable()
export class RecentSearchesService {

  recentSearches;

  getRecentSearches() {
    const array = localStorage.getItem('recentSearches');
    if (array == null) {
      this.recentSearches = [];
    }else {
      this.recentSearches = JSON.parse(array);
    }
  }

  addRecentSearch(place: string) {
    const obj = JSON.parse(localStorage.getItem('recentSearches'));
    if (obj == null) {
      this.recentSearches.push(place);
      localStorage.setItem('recentSearches', JSON.stringify(this.recentSearches));
    } else if (!obj.includes(place)) {
      this.recentSearches.push(place);
      localStorage.setItem('recentSearches', JSON.stringify(this.recentSearches));
    }
  }

  constructor() {
    this.getRecentSearches();
  }

}
